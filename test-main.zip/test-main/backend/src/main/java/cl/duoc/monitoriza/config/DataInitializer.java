package cl.duoc.monitoriza.config;



import java.time.DayOfWeek;

import java.time.LocalDate;

import java.time.LocalDateTime;

import java.time.LocalTime;

import java.util.ArrayList;

import java.util.List;

import java.util.Random;



import org.springframework.beans.factory.annotation.Value;

import org.springframework.boot.CommandLineRunner;

import org.springframework.core.annotation.Order;

import org.springframework.stereotype.Component;



import cl.duoc.monitoriza.model.Institucion;

import cl.duoc.monitoriza.model.Medicion;

import cl.duoc.monitoriza.model.Nodo;

import cl.duoc.monitoriza.model.Sala;

import cl.duoc.monitoriza.repository.InstitucionRepository;

import cl.duoc.monitoriza.repository.MedicionRepository;

import cl.duoc.monitoriza.repository.NodoRepository;

import cl.duoc.monitoriza.repository.SalaRepository;

import cl.duoc.monitoriza.service.InformeService;



@Component

@Order(1)

public class DataInitializer implements CommandLineRunner {



    private final InstitucionRepository institucionRepository;

    private final SalaRepository salaRepository;

    private final NodoRepository nodoRepository;

    private final MedicionRepository medicionRepository;

    private final InformeService informeService;



    @Value("${app.seed.historico.enabled:true}")

    private boolean historicoEnabled;

    @Value("${app.seed.historico.intervalo-minutos:5}")

    private int intervaloMinutos;

    @Value("${app.seed.historico.hora-inicio:07:30}")

    private String horaInicio;

    @Value("${app.seed.historico.hora-fin:16:30}")

    private String horaFin;

    @Value("${app.seed.historico.solo-laboral:true}")

    private boolean soloLaboral;

    @Value("${app.seed.informes.enabled:true}")

    private boolean informesHistoricoEnabled;



    public DataInitializer(

            InstitucionRepository institucionRepository,

            SalaRepository salaRepository,

            NodoRepository nodoRepository,

            MedicionRepository medicionRepository,

            InformeService informeService) {

        this.institucionRepository = institucionRepository;

        this.salaRepository = salaRepository;

        this.nodoRepository = nodoRepository;

        this.medicionRepository = medicionRepository;

        this.informeService = informeService;

    }



    @Override

    public void run(String... args) {

        Nodo nodo;



        if (nodoRepository.count() == 0) {

            Institucion institucion = new Institucion(

                    "Liceo Politécnico San Joaquín",

                    "Av. San Joaquín 123, San Joaquín, Chile, colegio particular subvencionado");

            institucionRepository.save(institucion);



            Sala sala = new Sala("2° medio A", 50.0, 30, 6, institucion, "no", "cruzada", 1);

            salaRepository.save(sala);



            nodo = new Nodo(

                    "Nodo 1 - Sala: 2° medio A",

                    "Nodo de medición de temperatura, humedad, db, lux, eco2 y tvoc",

                    sala);

            nodoRepository.save(nodo);

            System.out.println("[Seed] Datos base creados (institución, sala, nodo).");

        } else {

            nodo = nodoRepository.findAll().get(0);

            System.out.println("[Seed] Datos base ya existen.");

        }



        RangoHistorico rango = calcularRangoHistorico(LocalDateTime.now());



        if (medicionRepository.count() == 0 && historicoEnabled) {

            int total = generarHistoricoMensual(nodo, rango);

            System.out.println("[Seed] Histórico mensual creado: " + total + " mediciones.");

        } else if (medicionRepository.count() > 0) {

            System.out.println("[Seed] Mediciones ya existen (" + medicionRepository.count() + " registros).");

        } else {

            System.out.println("[Seed] Histórico de mediciones desactivado (app.seed.historico.enabled=false).");

        }



        if (informesHistoricoEnabled && medicionRepository.count() > 0) {
            informeService.generarInformesPendientes(rango.desde(), rango.hasta());
        } else if (!informesHistoricoEnabled) {

            System.out.println("[Seed] Generación de informes históricos desactivada.");

        }

    }



    private RangoHistorico calcularRangoHistorico(LocalDateTime inicioPrograma) {

        LocalDateTime fechaLimite = alinearHaciaAbajo(

                inicioPrograma.minusMinutes(intervaloMinutos),

                intervaloMinutos);

        LocalDate fechaDesde = fechaLimite.toLocalDate().minusMonths(1);

        LocalDate fechaHasta = fechaLimite.toLocalDate();

        return new RangoHistorico(fechaDesde, fechaHasta, fechaLimite);

    }



    private int generarHistoricoMensual(Nodo nodo, RangoHistorico rango) {

        LocalTime inicioDia = LocalTime.parse(horaInicio);

        LocalTime finDia = LocalTime.parse(horaFin);



        System.out.println("[Seed] Rango histórico: " + rango.desde() + " → " + rango.limite()

                + " (cada " + intervaloMinutos + " min, " + horaInicio + "–" + horaFin + ")");



        List<Medicion> lote = new ArrayList<>();

        int total = 0;

        Random random = new Random(42);



        for (LocalDate dia = rango.desde(); !dia.isAfter(rango.hasta()); dia = dia.plusDays(1)) {

            if (soloLaboral && esFinDeSemana(dia)) {

                continue;

            }



            LocalDateTime momento = dia.atTime(inicioDia);

            LocalDateTime finMomento = dia.atTime(finDia);



            while (!momento.isAfter(finMomento)) {

                if (momento.isAfter(rango.limite())) {

                    break;

                }



                Medicion m = generarMedicionParaMomento(momento, nodo, random);

                m.setFechaHora(momento);

                lote.add(m);

                total++;



                if (lote.size() >= 500) {

                    medicionRepository.saveAll(lote);

                    lote.clear();

                }



                momento = momento.plusMinutes(intervaloMinutos);

            }

        }



        if (!lote.isEmpty()) {

            medicionRepository.saveAll(lote);

        }



        return total;

    }



    private Medicion generarMedicionParaMomento(LocalDateTime t, Nodo nodo, Random random) {

        int hora = t.getHour();



        double factorClase;

        if (hora >= 9 && hora < 12) {

            factorClase = 1.0;

        } else if (hora >= 13 && hora < 16) {

            factorClase = 0.9;

        } else if (hora == 12) {

            factorClase = 0.5;

        } else {

            factorClase = 0.6;

        }



        double temperatura = redondear1(21.0 + (hora - 8) * 0.08 + ruido(random, -0.4, 0.4));

        double humedad = redondear1(50.0 + factorClase * ruido(random, 0, 8) + ruido(random, -2, 2));

        double db = redondear1(32.0 + factorClase * ruido(random, 0, 14));

        double lux = Math.round(300 + factorClase * ruido(random, 0, 140));

        double eco2 = Math.round(460 + factorClase * ruido(random, 0, 260));

        double tvoc = Math.round(150 + factorClase * ruido(random, 0, 150));



        if (random.nextDouble() < 0.06) {

            return inyectarOutlier(temperatura, humedad, db, lux, eco2, tvoc, random, nodo);

        }



        return new Medicion(temperatura, humedad, db, lux, eco2, tvoc, nodo);

    }



    private Medicion inyectarOutlier(

            double temperatura, double humedad, double db, double lux,

            double eco2, double tvoc, Random random, Nodo nodo) {



        int tipo = random.nextInt(6);



        switch (tipo) {

            case 0 -> temperatura = redondear1(23.5 + ruido(random, 0, 1.5));

            case 1 -> humedad = redondear1(62.0 + ruido(random, 0, 4));

            case 2 -> db = redondear1(48.0 + ruido(random, 0, 6));

            case 3 -> lux = Math.round(250 + ruido(random, 0, 40));

            case 4 -> eco2 = Math.round(820 + ruido(random, 0, 120));

            case 5 -> tvoc = Math.round(250 + ruido(random, 0, 100));

        }



        return new Medicion(temperatura, humedad, db, lux, eco2, tvoc, nodo);

    }



    private LocalDateTime alinearHaciaAbajo(LocalDateTime dt, int intervaloMinutos) {

        int minutoAlineado = (dt.getMinute() / intervaloMinutos) * intervaloMinutos;

        return dt.withMinute(minutoAlineado).withSecond(0).withNano(0);

    }



    private boolean esFinDeSemana(LocalDate dia) {

        DayOfWeek d = dia.getDayOfWeek();

        return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY;

    }



    private double ruido(Random random, double min, double max) {

        return min + (max - min) * random.nextDouble();

    }



    private double redondear1(double v) {

        return Math.round(v * 10.0) / 10.0;

    }



    private record RangoHistorico(LocalDate desde, LocalDate hasta, LocalDateTime limite) {}

}


